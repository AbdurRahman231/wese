import { Link, useLocation } from "wouter";
import { Home, Dumbbell, Target, ChevronLeft, Moon, Sun } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { Button } from "@/components/ui/button";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();
  const showBack = location !== "/";

  return (
    <div className="min-h-screen bg-background font-[Poppins]">
      <header className="fixed top-0 w-full bg-background/80 backdrop-blur-lg border-b z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            {showBack ? (
              <button onClick={() => window.history.back()} className="text-foreground">
                <ChevronLeft className="h-6 w-6" />
              </button>
            ) : (
              <div className="text-foreground font-bold text-xl">Marky.AI</div>
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
          </Button>
        </div>
      </header>

      <main className="pt-16 pb-20">{children}</main>

      <nav className="fixed bottom-0 w-full bg-background/80 backdrop-blur-lg border-t">
        <div className="container mx-auto px-4">
          <div className="flex justify-around py-3">
            <Link href="/">
              <a className="text-foreground flex flex-col items-center">
                <Home className="h-6 w-6" />
                <span className="text-xs mt-1">Home</span>
              </a>
            </Link>
            <Link href="/workouts">
              <a className="text-foreground flex flex-col items-center">
                <Dumbbell className="h-6 w-6" />
                <span className="text-xs mt-1">Workouts</span>
              </a>
            </Link>
            <Link href="/goals">
              <a className="text-foreground flex flex-col items-center">
                <Target className="h-6 w-6" />
                <span className="text-xs mt-1">Goals</span>
              </a>
            </Link>
          </div>
        </div>
      </nav>
    </div>
  );
}