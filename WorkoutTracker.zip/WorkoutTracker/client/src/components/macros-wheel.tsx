import { Card } from "@/components/ui/card";

interface MacrosWheelProps {
  protein: number;
  carbs: number;
  fats: number;
  calories: number;
}

export default function MacrosWheel({ 
  protein, 
  carbs, 
  fats,
  calories,
}: MacrosWheelProps) {
  const centerX = 100;
  const centerY = 100;

  // Create circle paths with different radiuses
  const createCircle = (percent: number, radius: number, color: string) => {
    const circumference = 2 * Math.PI * radius;
    const strokeDasharray = circumference;
    const strokeDashoffset = circumference * (1 - percent / 100);

    return (
      <circle
        cx={centerX}
        cy={centerY}
        r={radius}
        fill="none"
        stroke={color}
        strokeWidth="8"
        strokeLinecap="round"
        strokeDasharray={strokeDasharray}
        strokeDashoffset={strokeDashoffset}
        transform={`rotate(-90 ${centerX} ${centerY})`}
      />
    );
  };

  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-2">Today</h3>
      <p className="text-sm text-muted-foreground mb-4">Summary</p>
      <div className="flex items-center gap-4">
        <div className="relative" style={{ width: '200px', height: '200px' }}>
          <svg width="200" height="200" viewBox="0 0 200 200">
            {/* Background circles */}
            <circle cx={centerX} cy={centerY} r="70" stroke="#e5e7eb" strokeWidth="8" fill="none" />
            <circle cx={centerX} cy={centerY} r="55" stroke="#e5e7eb" strokeWidth="8" fill="none" />
            <circle cx={centerX} cy={centerY} r="40" stroke="#e5e7eb" strokeWidth="8" fill="none" />
            <circle cx={centerX} cy={centerY} r="25" stroke="#e5e7eb" strokeWidth="8" fill="none" />

            {/* Progress circles */}
            {createCircle(100 * (calories / 2000), 70, '#6366f1')} {/* Calories - Purple */}
            {createCircle(100 * (carbs / 250), 55, '#60a5fa')} {/* Carbs - Blue */}
            {createCircle(100 * (fats / 70), 40, '#8b5cf6')} {/* Fats - Purple */}
            {createCircle(100 * (protein / 150), 25, '#f59e0b')} {/* Protein - Orange */}
          </svg>

          {/* Values in center */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>{carbs}</div>
                <div>{fats}</div>
                <div>{protein}</div>
                <div>{calories}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Color keys with full names */}
        <div className="text-sm space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-[#f59e0b]" />
            <span className="font-medium">Protein</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-[#60a5fa]" />
            <span className="font-medium">Carbs</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-[#8b5cf6]" />
            <span className="font-medium">Fat</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-[#6366f1]" />
            <span className="font-medium">Calories</span>
          </div>
        </div>
      </div>
    </Card>
  );
}