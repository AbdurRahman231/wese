import { Line } from "recharts";
import { Card } from "@/components/ui/card";
import { type Exercise } from "@shared/schema";

interface ProgressChartProps {
  exercises: Exercise[];
}

export default function ProgressChart({ exercises }: ProgressChartProps) {
  const data = exercises.map((exercise) => ({
    name: new Date(exercise.date).toLocaleDateString(),
    weight: exercise.weight,
  }));

  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-4">Progress Over Time</h3>
      <div className="w-full h-[200px]">
        <Line
          data={data}
          margin={{ top: 5, right: 20, bottom: 5, left: 0 }}
        >
          <Line type="monotone" dataKey="weight" stroke="#8884d8" />
        </Line>
      </div>
    </Card>
  );
}
