import { Link } from "wouter";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { type Workout } from "@shared/schema";

interface WorkoutCardProps {
  workout: Workout;
}

export default function WorkoutCard({ workout }: WorkoutCardProps) {
  return (
    <Link href={`/workouts/${workout.id}`}>
      <Card className="cursor-pointer hover:bg-accent transition-colors">
        <CardHeader>
          <h3 className="font-semibold">{workout.name}</h3>
          <p className="text-sm text-muted-foreground">
            {new Date(workout.date).toLocaleDateString()}
          </p>
        </CardHeader>
        <CardContent>
          <p className="text-sm">Duration: {workout.duration} minutes</p>
          {workout.notes && (
            <p className="text-sm text-muted-foreground mt-2">{workout.notes}</p>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
