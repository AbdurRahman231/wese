import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { insertWorkoutSchema } from "@shared/schema";
import { Form } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";

export default function AddWorkout() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(insertWorkoutSchema),
    defaultValues: {
      name: "",
      duration: 0,
      sets: 0,
      reps: 0,
      weight: 0,
      notes: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/workouts", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workouts"] });
      toast({
        title: "Success",
        description: "Workout added successfully",
      });
      navigate("/workouts");
    },
  });

  const onSubmit = (data: any) => {
    mutation.mutate(data);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-foreground mb-6">New Workout</h1>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="space-y-2">
            <label className="text-foreground">Workout Name</label>
            <Input {...form.register("name")} className="bg-background" />
          </div>

          <div className="space-y-2">
            <label className="text-foreground">Duration (minutes)</label>
            <Input
              type="number"
              {...form.register("duration", { valueAsNumber: true })}
              className="bg-background"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-foreground">Sets</label>
              <Input
                type="number"
                {...form.register("sets", { valueAsNumber: true })}
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <label className="text-foreground">Reps</label>
              <Input
                type="number"
                {...form.register("reps", { valueAsNumber: true })}
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <label className="text-foreground">Weight (kg)</label>
              <Input
                type="number"
                {...form.register("weight", { valueAsNumber: true })}
                className="bg-background"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-foreground">Notes</label>
            <Textarea {...form.register("notes")} className="bg-background" />
          </div>

          <Button
            type="submit"
            className="w-full dark:bg-red-600 dark:text-white dark:hover:bg-red-700"
            disabled={mutation.isPending}
          >
            {mutation.isPending ? "Adding..." : "Add Workout"}
          </Button>
        </form>
      </Form>
    </div>
  );
}