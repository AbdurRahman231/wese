import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { type Workout } from "@shared/schema";
import { format } from "date-fns";
import MacrosWheel from "@/components/macros-wheel";
import { useState } from "react";

export default function Home() {
  const { data: workouts } = useQuery<Workout[]>({ 
    queryKey: ["/api/workouts"]
  });

  const [expanded, setExpanded] = useState(false);
  const lastWorkout = workouts?.[0];

  // TODO: Replace with actual macros data from API
  const mockMacros = {
    protein: 25,
    carbs: 20,
    fats: 15,
    calories: 450
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center text-foreground mb-12">
        <h1 className="text-4xl font-bold mb-2">Marky.AI</h1>
        <p className="text-xl">Making You Stronger Every Day</p>
      </div>

      <div className="space-y-6">
        <Link href="/add-workout">
          <Button 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white dark:bg-red-600 dark:hover:bg-red-700" 
            size="lg"
          >
            Start New Workout
          </Button>
        </Link>

        <div className="flex gap-4 items-start">
          <MacrosWheel {...mockMacros} />

          {lastWorkout && (
            <Card 
              className="flex-1 cursor-pointer hover:bg-accent transition-colors"
              onClick={() => setExpanded(!expanded)}
            >
              <CardContent className="p-6">
                <h2 className="text-lg font-semibold mb-2">Last Workout</h2>
                <p className="mb-2">{lastWorkout.name} - {format(new Date(lastWorkout.date), "dd/MMM/yy")}</p>

                {expanded && (
                  <div className="mt-4 space-y-2">
                    <p>Duration: {lastWorkout.duration} minutes</p>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="font-semibold">Sets</p>
                        <p>{lastWorkout.sets}</p>
                      </div>
                      <div>
                        <p className="font-semibold">Reps</p>
                        <p>{lastWorkout.reps}</p>
                      </div>
                      <div>
                        <p className="font-semibold">Weight</p>
                        <p>{lastWorkout.weight}kg</p>
                      </div>
                    </div>
                    {lastWorkout.notes && (
                      <p className="text-sm text-muted-foreground">{lastWorkout.notes}</p>
                    )}
                    <Link href={`/workouts/${lastWorkout.id}`}>
                      <Button variant="outline" className="w-full mt-4">View Details</Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
        <Link href="/workouts">
          <Button className="w-full" variant="outline" size="lg">
            View All Workouts
          </Button>
        </Link>
      </div>
    </div>
  );
}