import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { type Workout } from "@shared/schema";

export default function Profile() {
  const { data: workouts } = useQuery<Workout[]>({
    queryKey: ["/api/workouts"]
  });

  const totalWorkouts = workouts?.length || 0;
  const totalMinutes = workouts?.reduce((acc, w) => acc + w.duration, 0) || 0;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center text-white mb-8">
        <h1 className="text-2xl font-bold mb-2">Your Profile</h1>
        <p>Track your fitness journey</p>
      </div>

      <div className="grid gap-4">
        <Card>
          <CardContent className="p-6">
            <h2 className="font-semibold mb-2">Total Workouts</h2>
            <p className="text-3xl font-bold">{totalWorkouts}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="font-semibold mb-2">Total Minutes</h2>
            <p className="text-3xl font-bold">{totalMinutes}</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
