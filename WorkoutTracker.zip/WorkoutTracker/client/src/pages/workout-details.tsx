import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { type Workout } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function WorkoutDetails() {
  const { id } = useParams();
  const { data: workout, isLoading } = useQuery<Workout>({
    queryKey: [`/api/workouts/${id}`]
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 space-y-4">
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (!workout) return <div>Workout not found</div>;

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="mb-6">
        <CardContent className="p-6">
          <h1 className="text-2xl font-bold mb-2">{workout.name}</h1>
          <p className="text-muted-foreground">
            {new Date(workout.date).toLocaleDateString()}
          </p>
          <p className="mt-2">Duration: {workout.duration} minutes</p>

          <div className="mt-4 grid grid-cols-3 gap-4">
            <div>
              <p className="font-semibold">Sets</p>
              <p>{workout.sets}</p>
            </div>
            <div>
              <p className="font-semibold">Reps</p>
              <p>{workout.reps}</p>
            </div>
            <div>
              <p className="font-semibold">Weight</p>
              <p>{workout.weight}kg</p>
            </div>
          </div>

          {workout.notes && <p className="mt-4">{workout.notes}</p>}
        </CardContent>
      </Card>
    </div>
  );
}