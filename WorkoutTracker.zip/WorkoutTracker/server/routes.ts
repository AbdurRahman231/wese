import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertWorkoutSchema } from "@shared/schema";

export async function registerRoutes(app: Express) {
  const httpServer = createServer(app);

  // Workout routes
  app.get("/api/workouts", async (req, res) => {
    const workouts = await storage.getAllWorkouts();
    res.json(workouts);
  });

  app.get("/api/workouts/:id", async (req, res) => {
    const workout = await storage.getWorkout(Number(req.params.id));
    if (!workout) {
      res.status(404).json({ message: "Workout not found" });
      return;
    }
    res.json(workout);
  });

  app.post("/api/workouts", async (req, res) => {
    const parsed = insertWorkoutSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ message: "Invalid workout data" });
      return;
    }
    const workout = await storage.createWorkout(parsed.data);
    res.json(workout);
  });

  return httpServer;
}