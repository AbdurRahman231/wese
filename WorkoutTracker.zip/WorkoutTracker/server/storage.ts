import { type Workout, type InsertWorkout } from "@shared/schema";

export interface IStorage {
  // Workout operations
  getAllWorkouts(): Promise<Workout[]>;
  getWorkout(id: number): Promise<Workout | undefined>;
  createWorkout(workout: InsertWorkout): Promise<Workout>;
}

export class MemStorage implements IStorage {
  private workouts: Map<number, Workout>;
  private workoutId: number;

  constructor() {
    this.workouts = new Map();
    this.workoutId = 1;
  }

  async getAllWorkouts(): Promise<Workout[]> {
    return Array.from(this.workouts.values()).sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }

  async getWorkout(id: number): Promise<Workout | undefined> {
    return this.workouts.get(id);
  }

  async createWorkout(workout: InsertWorkout): Promise<Workout> {
    const id = this.workoutId++;
    const newWorkout = { 
      ...workout, 
      id,
      date: new Date(),
      sets: workout.sets || 0,
      reps: workout.reps || 0,
      weight: workout.weight || 0,
      notes: workout.notes || null
    };
    this.workouts.set(id, newWorkout);
    return newWorkout;
  }
}

export const storage = new MemStorage();