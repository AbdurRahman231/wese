import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const workouts = pgTable("workouts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  date: timestamp("date").notNull().defaultNow(),
  duration: integer("duration").notNull(), // in minutes
  sets: integer("sets").notNull().default(0),
  reps: integer("reps").notNull().default(0),
  weight: integer("weight").notNull().default(0), // in kg
  notes: text("notes"),
});

export const insertWorkoutSchema = createInsertSchema(workouts).omit({ id: true });

export type Workout = typeof workouts.$inferSelect;
export type InsertWorkout = z.infer<typeof insertWorkoutSchema>;